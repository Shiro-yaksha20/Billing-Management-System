import os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from .models import Bill
from .database import get_db
from . import settings_service

RECEIPTS_DIR = "receipts"

def generate_receipt_pdf(bill_id: int) -> str:
    """
    Generates a PDF receipt for the given bill and returns the file path.
    """
    if not os.path.exists(RECEIPTS_DIR):
        os.makedirs(RECEIPTS_DIR)
        
    db_gen = get_db()
    db = next(db_gen)
    try:
        bill = db.query(Bill).filter(Bill.id == bill_id).first()
        if not bill:
            raise ValueError(f"Bill with id {bill_id} not found.")

        file_path = os.path.join(RECEIPTS_DIR, f"receipt_{bill.id}.pdf")
        doc = SimpleDocTemplate(file_path, pagesize=letter)
        styles = getSampleStyleSheet()
        story = []

        # Salon Details
        story.append(Paragraph(settings_service.get_setting("salon_name", "Your Salon"), styles['h1']))
        story.append(Paragraph(settings_service.get_setting("salon_address", "123 Salon St."), styles['Normal']))
        story.append(Paragraph(settings_service.get_setting("salon_phone", "555-1234"), styles['Normal']))
        story.append(Spacer(1, 12))

        # Bill Details
        story.append(Paragraph(f"Receipt for Bill #{bill.id}", styles['h2']))
        story.append(Paragraph(f"Date: {bill.bill_datetime.strftime('%Y-%m-%d %H:%M')}", styles['Normal']))
        story.append(Paragraph(f"Customer: {bill.customer.name}", styles['Normal']))
        story.append(Paragraph(f"Stylist: {bill.staff.name}", styles['Normal']))
        story.append(Spacer(1, 12))

        # Bill Items Table
        data = [["Service", "Qty", "Unit Price", "Total"]]
        for item in bill.items:
            data.append([
                item.service.name,
                str(item.quantity),
                f"₹{item.unit_price:.2f}",
                f"₹{item.line_total:.2f}"
            ])
        
        table = Table(data)
        style = TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ])
        table.setStyle(style)
        story.append(table)
        story.append(Spacer(1, 12))

        # Totals
        story.append(Paragraph(f"Subtotal: ₹{bill.subtotal:.2f}", styles['Normal']))
        story.append(Paragraph(f"Discount: -₹{bill.discount_amount:.2f}", styles['Normal']))
        story.append(Paragraph(f"Tax ({bill.tax_percent}%): +₹{bill.tax_amount:.2f}", styles['Normal']))
        story.append(Paragraph(f"Total: ₹{bill.total:.2f}", styles['h3']))
        story.append(Spacer(1, 12))

        # Thank you message
        story.append(Paragraph(settings_service.get_setting("thank_you_message", "Thanks for your visit!"), styles['Italic']))
        
        doc.build(story)
        
        # Save PDF path to bill
        bill.pdf_path = file_path
        db.commit()

        return file_path
    finally:
        db.close()
