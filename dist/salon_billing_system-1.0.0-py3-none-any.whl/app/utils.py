import logging
import os

LOGS_DIR = "logs"

def setup_logger():
    """Sets up a basic file logger."""
    if not os.path.exists(LOGS_DIR):
        os.makedirs(LOGS_DIR)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(os.path.join(LOGS_DIR, "app.log")),
            logging.StreamHandler()
        ]
    )

    return logging.getLogger(__name__)

logger = setup_logger()
