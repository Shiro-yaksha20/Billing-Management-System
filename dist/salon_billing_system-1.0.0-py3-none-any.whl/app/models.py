import datetime
from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    Boolean,
    Text,
    DateTime,
    ForeignKey,
    Numeric,
    Enum,
)
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.sql import func

Base = declarative_base()


class TimestampMixin:
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class Staff(Base, TimestampMixin):
    __tablename__ = "staff"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    phone = Column(String)
    role = Column(String)
    active = Column(Boolean, default=True)

    bills = relationship("Bill", back_populates="staff")


class Service(Base, TimestampMixin):
    __tablename__ = "service"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    description = Column(String)
    price = Column(Numeric(10, 2))
    duration_minutes = Column(Integer)
    active = Column(Boolean, default=True)


class Customer(Base, TimestampMixin):
    __tablename__ = "customer"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    notes = Column(Text)
    last_visit_at = Column(DateTime)

    bills = relationship("Bill", back_populates="customer")


class Bill(Base, TimestampMixin):
    __tablename__ = "bill"
    id = Column(Integer, primary_key=True)
    bill_number = Column(String, unique=True)
    customer_id = Column(Integer, ForeignKey("customer.id"), nullable=False)
    staff_id = Column(Integer, ForeignKey("staff.id"), nullable=False)
    bill_datetime = Column(DateTime, default=datetime.datetime.utcnow)
    subtotal = Column(Numeric(10, 2))
    discount_amount = Column(Numeric(10, 2), default=0)
    discount_type = Column(Enum("flat", "percent", "none", name="discount_type_enum"), default="none")
    tax_amount = Column(Numeric(10, 2), default=0)
    tax_percent = Column(Numeric(5, 2))
    total = Column(Numeric(10, 2), nullable=False)
    payment_method = Column(Enum("Cash", "UPI", "Card", "Other", name="payment_method_enum"), default="Cash")
    status = Column(Enum("Paid", "Pending", "Cancelled", name="status_enum"), default="Paid")
    pdf_path = Column(String)
    whatsapp_status = Column(Enum("Not Sent", "Sent", "Failed", name="whatsapp_status_enum"), default="Not Sent")
    whatsapp_last_error = Column(Text)

    customer = relationship("Customer", back_populates="bills")
    staff = relationship("Staff", back_populates="bills")
    items = relationship("BillItem", back_populates="bill", cascade="all, delete-orphan")


class BillItem(Base):
    __tablename__ = "bill_item"
    id = Column(Integer, primary_key=True)
    bill_id = Column(Integer, ForeignKey("bill.id"))
    service_id = Column(Integer, ForeignKey("service.id"))
    quantity = Column(Integer, default=1)
    unit_price = Column(Numeric(10, 2))
    line_total = Column(Numeric(10, 2))

    bill = relationship("Bill", back_populates="items")
    service = relationship("Service")


class Setting(Base):
    __tablename__ = "setting"
    id = Column(Integer, primary_key=True)
    key = Column(String, unique=True, nullable=False)
    value = Column(Text)
